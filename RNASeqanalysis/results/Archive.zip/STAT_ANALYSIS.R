###############################################################################
# STAT ANALYSIS
###############################################################################
# --- INPUT FILE PATHS (Arguments passed from Nextflow) ---
# NOTE: These paths must be set correctly in the calling script.

coldata_path <- "/Users/marie/Downloads/coldata.tsv"
count_matrix_path <- "/Users/marie/Downloads/counts.txt"
output_file <- "ma_plot_test.png"

# --- REQUIRED LIBRARIES ---
# Assuming these are installed in your mariemeier/reprohackathon:deseq2 container
library(DESeq2) 


# --- 1. LOAD AND HARMONIZE COL DATA ---

# Load coldata: First column (SRR_ID) must become row names.
coldata <- read.table(coldata_path, header = TRUE, sep = "\t", 
                      row.names = 1, stringsAsFactors = TRUE)

# Clean and finalize Condition factor
# Convert IP and control to factors.
coldata$Condition <- factor(coldata$Condition)
# Set 'control' as the reference level for log2FC calculation
coldata$Condition <- relevel(coldata$Condition, ref = "control") 


# --- 2. LOAD, CLEAN, AND HARMONIZE COUNT MATRIX (FIXING THE SUFFIX ERROR) ---

# Load the count matrix (it's a text file separated by tabs)
# Skip the header comments (# Program:...) and use the column names (Geneid, Chr, etc.)
# Note: read.table is flexible and should handle the initial commented lines.
counts_matrix_raw <- read.table(count_matrix_path, header = TRUE, row.names = 1, 
                                sep = "\t", stringsAsFactors = FALSE)
counts_matrix_raw <- as.matrix(counts_matrix_raw)

colnames(counts_matrix_raw)
# A. Filter out descriptive columns and keep only count columns (the last 6 columns)
# The first 6 columns after Geneid (Chr to Length) are descriptive.
# We take columns 7 to 12 (the columns with SRR IDs).
counts_matrix <- counts_matrix_raw[, 6:11]


# B. HARMONIZATION FIX (Crucial for eliminating "subscript out of bounds")
# The column names contain the suffix ".bam" which MUST BE REMOVED.
colnames(counts_matrix) <- gsub("\\.bam$", "", colnames(counts_matrix))


# C. Final Harmonization and Reordering
# Now that names match (SRRxxxxxx == SRRxxxxxx), we reorder the matrix columns 
# according to the exact sample order in coldata.
counts_matrix <- counts_matrix[, rownames(coldata)] 

counts_matrix <- apply(counts_matrix, 2, as.numeric) 
# Note: L'étape précédente perd les noms de lignes (geneid), mais ils sont conservés dans le Rownames original.
# Rétablir les Rownames (Geneid)
rownames(counts_matrix) <- rownames(counts_matrix_raw)
# Rétablir les Colnames (SRR_ID)
colnames(counts_matrix) <- rownames(coldata)



# Create the DESeqDataSet object
dds <- DESeqDataSetFromMatrix(
  countData = round(counts_matrix), # Needs integer counts
  colData = coldata,
  design = ~ Condition 
)

# Run the DESeq2 analysis (Normalization, Dispersion estimation, Wald test)
# The article mentioned using default parameters (which this call does)
dds <- DESeq(dds)

# Extract results (IP vs control)
res <- results(dds, contrast = c("Condition", "IP", "control"), alpha = 0.05)


# --- 4. MA-PLOT GENERATION (Base R Finalisé - Grille Style ggplot2) ---

# ... (Votre code pour charger les données, exécuter DESeq2 et préparer M, A, point_colors) ...

# Ouvrir le périphérique graphique PNG
png(output_file, width = 800, height = 800, res = 150)

# --- CRÉATION DU GRAPHIQUE ---

# 1. Préparer l'environnement graphique
par(
  bg = "white", # Fond blanc pur
  mar = c(5, 5, 4, 2) + 0.1, # Marges standards
  col.axis = "gray30", # Couleur des labels d'axe
  col.lab = "gray30", # Couleur des titres d'axe
  fg = "gray30", # Couleur des bords des axes (sera masqué par bty="n")
  cex.axis = 1, # Taille des labels d'axe
  cex.lab = 1 # Taille des titres d'axe
)

# 2. TRACER LE GRAPHIQUE DE BASE (sans points, avec la grille personnalisée)
plot(
  x = A, 
  y = M, 
  type = "n", # Ne dessine pas les points (pour dessiner d'abord la grille)
  ylim = c(-4, 4), 
  main = "Supp. Fig. 3.: MA-plot of complete RNA-seq dataset", 
  xlab = "Mean of normalized counts", 
  ylab = "log2 fold change",
  xaxt = 'n', # Supprimer l'axe X par défaut
  yaxt = 'n', # Supprimer l'axe Y par défaut
  bty = "n", # Supprimer la boîte autour du graphique
  
  # AJOUT DE LA GRILLE FINE STYLE GGPLOT2
  panel.first = {
    abline(h = seq(-4, 4, by = 1), col = "gray90", lty = 1) # Lignes horizontales fines
    abline(v = log2(c(1, 10, 100, 1000, 10000, 100000)), col = "gray90", lty = 1) # Lignes verticales fines
  }
)

# 3. DESSINER LES AXES ET L'ÉCHELLE

# Ajouter l'axe Y avec les labels à gauche (las=1)
axis(side = 2, at = seq(-4, 4, by = 2), las = 1, col = "gray30", col.ticks = "gray30") 

# Ajouter l'axe X personnalisé (Échelle logarithmique 10^x)
breaks_log2 <- log2(c(1, 100, 10000)) 

axis(
  side = 1, 
  at = breaks_log2, 
  labels = c(expression(10^0), expression(10^2), expression(10^4)),
  lwd = 0,            
    lwd.ticks = 1,
  col.axis = "black" 
)

# 4. DESSINER LES POINTS ET TRIANGLES
points(
  x = A[M < 4 & M > -4], 
  y = M[M < 4 & M > -4], 
  col = point_colors[M < 4 & M > -4], 
  pch = 20, 
  cex = 0.5
)

points(
  x = A[M >= 4], 
  y = rep(4, length(M[M >= 4])), 
  col = point_colors[M >= 4], 
  pch = 24, 
  cex = 0.8
)

points(
  x = A[M <= -4], 
  y = rep(-4, length(M[M <= -4])), 
  col = point_colors[M <= -4], 
  pch = 25, 
  cex = 0.8
)

# 5. Ajouter la ligne de référence à y=0 (ligne pointillée)
abline(h = 0, col = "gray50", lty = 2)

# Fermer le périphérique graphique
dev.off()